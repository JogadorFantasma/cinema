# cinema
Painel e site voltado para a área de cinema
First commit foi para inserir o leiaute que será utilizado nesse site.
O projeto consiste de um painel e um site que terá todas as funções de pagamento online.
Projetado com: PHP, MySQL..
