<div class="zooks-promos-area-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="section-title text-center">
                        <h2>CADASTRE-SE E FIQUE POR DENTRO DA PROGRAMAÇÃO E PROMOÇÕES EXCLUSIVAS.</h2>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="input-group" style="margin-top:12vh;">
                        <form method="post">
                            <input style="width: 538px;" type="email" name="email" class="form-control"
                                placeholder="E-mail">
                            <span class="input-group-btn">
                                <button name="acao" value="enviar" class=" btn btn-default"
                                    type="submit">Enviar</button>
                            </span>
                        </form>
                    </div>
                </div>
                            </div>
                
        </div>
    </div>