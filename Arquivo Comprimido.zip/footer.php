   <!-- Footer Start Here -->
        <footer>
            <div class="footer-top-area">
                <div class="container">
                    <div class="row">
                        
                        <div class="col-lg-4 col-md-2 col-sm-4 col-xs-12">                            
                            <div class="widget">
                                <div class="footer-two">
                                    <div class="widget-title">Entre em Contato</div>
                                    <ul>
                                        <li><a href="<?php echo SITE_URL;?>/contato">Faq</a></li>
                                        <li><a href="<?php echo SITE_URL;?>/contato">Fale Conosco</a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-2 col-sm-4 col-xs-12">                            
                            <div class="widget">
                                <div class="footer-three">
                                    <div class="widget-title">Cinemas Premier</div>
                                    <ul>
                                    <li><a href="<?php echo SITE_URL;?>/sobre">Sobre</a></li>
                                        <li><a href="<?php echo SITE_URL;?>/filmes">Filmes em cartaz</a></li>
                                        <li><a href="<?php echo SITE_URL;?>/filmes">Filmes em breve</a></li>
                                        <li><a href="<?php echo SITE_URL;?>/produtos">Produtos</a></li>
                                    </ul>
    
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-2 col-sm-4 col-xs-12">                            
                            <div class="widget">
                                <div class="footer-four">
                                    <div class="widget-title">CONECTE-SE CONOSCO</div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</a></li>
                                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i> Instagram</a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                            <div class="footer-text">
                                <p>© 2009-<?php echo date('Y');?> Feito com <i class="icon icon-heart fa-beat" style="color: red;"></i> por <span><a href="http://hoogli.com.br/" target="_blank"><img src="<?php echo SITE_URL;?>/images/hoogli_logo.svg" width="60" alt="Hoogli-Marketing-Digital-Brasilia-(61)-3436-1999" style="margin-top: 3px;"></a></span>. Todos os direitos reservados.</p>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer End Here -->