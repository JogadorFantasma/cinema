<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="css/style.css"/>
<link rel="stylesheet" href="css/styles.css"/>
<link rel="icon" sizes="192x192" href="//infoenem.com.br/logo-infoenem.png">

<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#124f77">
<meta name="msapplication-navbutton-color" content="#124f77">
<meta name="apple-mobile-web-app-status-bar-style" content="#124f77">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<title>Tela de Pagamento</title>

<!-- * -->

<script type="text/javascript" src="//code.jquery.com/jquery-1.12.4.min.js" charset="utf-8"></script>
<script type='text/javascript' src='js/cepC.js'></script>
<script type='text/javascript' src='js/cepV.js'></script>
<script type='text/javascript' src="js/maskedinput.js"></script>